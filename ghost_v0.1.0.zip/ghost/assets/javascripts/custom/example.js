(function($, window) {

	console.log( 'custom script' );

})( jQuery, window );