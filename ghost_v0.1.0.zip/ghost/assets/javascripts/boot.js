jQuery(function($) {
	riot.mount( '*' );
});