module.exports = {
	options: {
		jshintrc: true
	},
	beforeconcat: '<%= concat.dev.src %>'
};