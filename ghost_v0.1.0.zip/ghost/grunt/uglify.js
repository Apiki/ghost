module.exports = {
	dist: {
		files: {
			'<%= concat.dev.dest %>' : '<%= concat.dev.dest %>'
		}
	}
};